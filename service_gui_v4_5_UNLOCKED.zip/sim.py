"""Байтовый симулятор симулятора для проверки GUI без реального железа.

Реализует интерфейс, совместимый с pyserial (read/write/…), и отвечает
на безопасные команды чтения корректными кадрами с CRC. Для проверки
экспертного режима GUI симулятор принимает CMD 0x03/0x07. Для CMD 0x07
симулируется запись в условную внешнюю память, чтобы проверить один
тестовый запрос без реального устройствоа. Значения выдаются условные,
пригодные лишь для отладки интерфейса.
"""
from __future__ import annotations
import time
from stand import crc16, build, RESULT_BAD_REQUEST

# Условные данные «устройствоа» для отладки интерфейса.
SIM_SERIAL = 0x2E393D1C
SIM_DATE = (0x0C, 0x03, 0x16)      # день, месяц, год — как в INFO 0x1080
SIM_ADDR = 0x2A
SIM_CONFIG = bytes((0x02, 0x00, 0x2A, 0x00))  # 0x04E0..0x04E3: скорость 4800 и т.п.
SIM_PHASES = (0x0F1E, 0x0F20, 0x0F1D)


def _ar_encode_raw_u32_weird(raw: int) -> bytes:
    tmp = raw & 0xFFFFFFFF
    b2 = tmp & 0xFF; tmp >>= 8
    b3 = tmp & 0xFF; tmp >>= 8
    b0 = tmp & 0xFF; tmp >>= 8
    b1 = tmp & 0xFF
    return bytes([b0, b1, b2, b3])


def _ar_crc_xor_16(buf16: bytes) -> int:
    crc = 0xF0
    for x in buf16[:16]:
        crc ^= x
    return crc & 0xFF


def _ar_make_record(p: float, q: float, coef: int = 1000) -> bytes:
    rec = bytearray(17)
    rec[0:4] = _ar_encode_raw_u32_weird(int(round(p * coef)))
    rec[8:12] = _ar_encode_raw_u32_weird(int(round(q * coef)))
    rec[16] = _ar_crc_xor_16(bytes(rec[:16]))
    return bytes(rec)


# Условная внешняя память для вкладки v4 P/Q-01/P/Q-02: база 0x0000 и дубль 0x0100.
SIM_AR_RECORD = _ar_make_record(6384.36, 1445.71, 1000)
SIM_EXT_MEMORY = bytearray(0x0200)
SIM_EXT_MEMORY[0x0000:0x0000 + len(SIM_AR_RECORD)] = SIM_AR_RECORD
SIM_EXT_MEMORY[0x0100:0x0100 + len(SIM_AR_RECORD)] = SIM_AR_RECORD


def _sim_memory_read(mem_addr: int, length: int) -> bytes:
    out = bytearray()
    for a in range(mem_addr, mem_addr + length):
        if 0 <= a < len(SIM_EXT_MEMORY):
            out.append(SIM_EXT_MEMORY[a])
        else:
            out.append(0)
    return bytes(out)


def _sim_memory_write(mem_addr: int, data: bytes) -> None:
    for i, b in enumerate(data):
        a = mem_addr + i
        if 0 <= a < len(SIM_EXT_MEMORY):
            SIM_EXT_MEMORY[a] = b


class SimSerial:
    """Мини-замена serial.Serial: принимает кадр запроса, кладёт ответ в очередь."""

    def __init__(self, *_, **kwargs):
        self.timeout = kwargs.get("timeout", 0.5)
        self._rx = bytearray()   # то, что «устройство» отправит хосту
        self._tx = bytearray()   # то, что хост отправил устройствоу
        self.is_open = True

    # --- API, используемый транспортом Stand ---
    def reset_input_buffer(self):
        self._rx.clear()

    def flush(self):
        pass

    def write(self, data: bytes):
        self._tx += data
        self._handle(bytes(data))
        return len(data)

    def read(self, n: int = 1) -> bytes:
        out = bytes(self._rx[:n])
        del self._rx[:n]
        return out

    def close(self):
        self.is_open = False

    # --- логика ответа ---
    def _reply(self, addr: int, body: bytes):
        self._rx += build(bytes((addr,)) + body)

    def _ack(self, addr: int, code: int = 0):
        self._rx += build(bytes((addr, code)))

    def _handle(self, frame: bytes):
        if len(frame) < 4 or crc16(frame) != 0:
            return
        addr, cmd = frame[0], frame[1]
        args = frame[2:-2]
        r = addr if addr else SIM_ADDR
        if cmd == 0x00:                       # тест связи
            self._ack(r)
        elif cmd == 0x01:                     # открытие канала (для симуляции — всегда OK)
            self._ack(r)
        elif cmd == 0x02:                     # закрытие канала
            self._ack(r)
        elif cmd == 0x08 and args:
            sub = args[0]
            if sub == 0x00:
                self._reply(r, SIM_SERIAL.to_bytes(4, "big") + bytes(SIM_DATE))
            elif sub in (0x04, 0x05):
                self._reply(r, bytes((SIM_ADDR,)))
            elif sub == 0x02:
                self._reply(r, SIM_CONFIG)
            elif sub == 0x09:
                self._reply(r, bytes((0x00, 0x04, 0x00, 0x00, 0x00, 0x00)))
            elif sub == 0x29:
                b = b"".join(v.to_bytes(2, "big") for v in SIM_PHASES)
                self._reply(r, b)
            elif sub == 0x07:                 # расширенная конфигурация
                self._reply(r, SIM_CONFIG + bytes((0x00, 0x00)))
            elif sub == 0x0A:
                self._reply(r, bytes((0x00, 0x00, 0x00, 0x00)))
            elif sub in (0x17, 0x1D):
                self._reply(r, bytes((SIM_ADDR,)))
            elif sub == 0x18:
                self._reply(r, bytes((0x00, 0x00)))
            elif sub == 0x19:
                self._reply(r, bytes((0x00, 0x00, 0x00)))
            elif sub == 0x1B:
                self._reply(r, bytes(8))
            elif sub == 0x1C:
                self._reply(r, bytes(4))
            elif sub == 0x1F:                 # служебная область (сервис активен в СИМ)
                self._reply(r, bytes(12))
            # Остальные реализованные CMD 0x08 из отчёта: условные данные для проверки UI.
            elif sub in (0x01, 0x03, 0x0B, 0x0C, 0x0D, 0x14, 0x26):
                self._ack(r)
            elif sub in (0x11, 0x16):          # служебные поля данных
                self._reply(r, bytes(8))
            elif sub == 0x12:
                self._reply(r, bytes((0x00, 0x00)))
            elif sub == 0x13:
                self._reply(r, bytes(4))
            elif sub == 0x1A:
                self._reply(r, SIM_CONFIG + bytes((0x00, 0x00)))
            elif sub == 0x1E:
                self._reply(r, bytes(3))
            elif sub == 0x20:
                self._reply(r, bytes(2))
            elif sub == 0x21:
                self._reply(r, bytes((0x02, SIM_ADDR, 0x00)))
            elif sub == 0x26:
                self._ack(r)
            elif sub == 0x27:
                self._reply(r, bytes(2))
            else:
                self._ack(r, RESULT_BAD_REQUEST)
        elif cmd == 0x03:                      # экспертная запись в СИМ: только квитанция
            self._ack(r, 0)
        elif cmd == 0x07:                      # запись в условную внешнюю память СИМ
            if len(args) >= 5:
                mode = args[0]
                mem_addr = ((args[1] << 8) | args[2]) & 0xFFFF
                length = args[3]
                payload = bytes(args[4:4 + length])
                if mode in (1, 2) and length == len(payload) and 1 <= length <= 16:
                    _sim_memory_write(mem_addr, payload)
                    self._ack(r, 0)
                else:
                    self._ack(r, RESULT_BAD_REQUEST)
            else:
                self._ack(r, RESULT_BAD_REQUEST)
        elif cmd == 0x06:                     # чтение памяти / внешних структур
            if len(args) >= 4:
                mem_addr = ((args[1] << 8) | args[2]) & 0xFFFF
                length = args[3]
            else:
                mem_addr, length = 0, 1
            self._reply(r, _sim_memory_read(mem_addr, length))
        else:
            self._ack(r, RESULT_BAD_REQUEST)


def make_sim_stand(address: int = 0x00):
    """Возвращает объект Stand, работающий поверх симулятора вместо COM-порта."""
    import stand as _s
    obj = _s.Stand.__new__(_s.Stand)
    obj.address = address
    obj.retries = 1
    obj._timeout = 0.2
    obj.on_frame = None
    obj._serial = SimSerial(timeout=0.2)
    obj._gap = 0.0
    return obj
