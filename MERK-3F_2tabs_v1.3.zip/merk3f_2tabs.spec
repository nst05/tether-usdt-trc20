# -*- mode: python ; coding: utf-8 -*-
"""
Спецификация PyInstaller: MERK-3F без вкладки 231-AT-01 (ART, AR)

Собирать через build_merk3f_2tabs.bat либо напрямую:
    pyinstaller --noconfirm --clean merk3f_2tabs.spec

Подводные камни, которые здесь закрыты:

1. CH341DLL грузится по голому имени прямо при обращении к программатору.
   В onefile-сборке файлы распакованы во временную папку sys._MEIPASS,
   которой нет в путях поиска DLL. Runtime-хук pyi_rth_ch341.py находит
   библиотеку и подставляет её полный путь в переменную CH341DLL —
   spi_memory читает эту переменную первой.

2. Заставку PyInstaller рисует tkinter. Его НЕЛЬЗЯ вносить в excludes,
   иначе сборка обрывается с «Your platform does not support the splash
   screen feature». Если tkinter в системе нет, spec это замечает и
   собирается без заставки.
"""

import os

BASE = os.path.abspath(os.getcwd())

# Имя итогового exe и точка входа. Менять здесь.
APP_NAME = "MERK-3F_2tabs"
ENTRY = "merk3f_2tabs.py"

# ── DLL для CH341, если она положена рядом ─────────────────────────────────
binaries = []
for dll in ("CH341DLLA64.dll", "CH341DLL.dll"):
    path = os.path.join(BASE, dll)
    if os.path.isfile(path):
        binaries.append((path, "."))

# ── Иконка ─────────────────────────────────────────────────────────────────
icon = os.path.join(BASE, "icon_srt.ico")
if not os.path.isfile(icon):
    icon = None

# Иконка нужна и внутри сборки: экран загрузки рисует её в центре кольца,
# доставая через sys._MEIPASS.
datas = []
for name in ("icon_srt.ico", "icon_srt.png"):
    path = os.path.join(BASE, name)
    if os.path.isfile(path):
        datas.append((path, "."))

# ── Заставка ───────────────────────────────────────────────────────────────
try:
    import tkinter  # noqa: F401
    _has_tk = True
except ImportError:
    _has_tk = False

splash_image = os.path.join(BASE, "icon_srt_splash.png")
use_splash = os.path.isfile(splash_image) and _has_tk


a = Analysis(
    [ENTRY],
    pathex=[BASE],
    binaries=binaries,
    datas=datas,
    hiddenimports=[
        "spi_memory",
        "srt_mod_spi",
        "splash_screen",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=["pyi_rth_ch341.py"],
    excludes=[
        # Лишний вес. tkinter здесь быть НЕ ДОЛЖНО: на нём заставка.
        "matplotlib", "numpy", "scipy", "pandas",
        "PyQt5.QtWebEngineWidgets", "PyQt5.QtWebEngine",
        "PyQt5.QtQuick", "PyQt5.QtQml", "PyQt5.Qt3DCore",
        "PyQt5.QtMultimedia", "PyQt5.QtBluetooth",
    ],
    noarchive=False,
)

pyz = PYZ(a.pure)

# С заставкой у EXE два лишних аргумента; без неё сборка должна проходить
# так же, поэтому список собирается по частям.
exe_parts = [pyz, a.scripts]

if use_splash:
    splash = Splash(
        splash_image,
        binaries=a.binaries,
        datas=a.datas,
        text_pos=(210, 214),
        text_size=9,
        text_color="#8B93A6",
        text_default="Raspakovka...",
        minify_script=True,
        always_on_top=True,
    )
    exe_parts += [splash, splash.binaries]

exe_parts += [a.binaries, a.datas, []]

exe = EXE(
    *exe_parts,
    name=APP_NAME,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=icon,
)
